int foo(int a) {
    if (a < 0) {
        a = 0;
    }
    return a;
}

int bar(int a) {
    if (a<0)
        a = 0;
    return a;
}

int func(int a) {
    if(a < 0)
        a = 0;
    return a;
}
